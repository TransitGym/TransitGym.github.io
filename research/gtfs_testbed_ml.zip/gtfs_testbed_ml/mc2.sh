python main714.py --control=3 --model=caac --train=1 --episode=800 --share_scale=0 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main714.py --control=4 --model=caac --train=1 --episode=800 --share_scale=0 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main714.py --control=5 --model=caac --train=1 --episode=800 --share_scale=0 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main714.py --control=6 --model=caac --train=1 --episode=800 --share_scale=0 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main714.py --control=3 --model=caac --train=1 --episode=800 --share_scale=0 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main714.py --control=4 --model=caac --train=1 --episode=800 --share_scale=0 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0 
python main714.py --control=5 --model=caac --train=1 --episode=800 --share_scale=0 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main714.py --control=6 --model=caac --train=1 --episode=800 --share_scale=0 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0 
python main714.py --control=3 --model=caac --train=1 --episode=800 --share_scale=0 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main714.py --control=4 --model=caac --train=1 --episode=800 --share_scale=0 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main714.py --control=5 --model=caac --train=1 --episode=800 --share_scale=0 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main714.py --control=6 --model=caac --train=1 --episode=800 --share_scale=0 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main714.py --control=3 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=0
python main714.py --control=3 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=0
python main714.py --control=3 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=0
python main714.py --control=4 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=0
python main714.py --control=4 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=0
python main714.py --control=4 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=0
python main714.py --control=5 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=0
python main714.py --control=5 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=0
python main714.py --control=5 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=0
python main714.py --control=6 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=0
python main714.py --control=6 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=0
python main714.py --control=6 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=0
python main714.py --control=3 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=2
python main714.py --control=3 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=2
python main714.py --control=3 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=2
python main714.py --control=4 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=2
python main714.py --control=4 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=2
python main714.py --control=4 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=2
python main714.py --control=5 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=2
python main714.py --control=5 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=2
python main714.py --control=5 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=2
python main714.py --control=6 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=2
python main714.py --control=6 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=2
python main714.py --control=6 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=2
python main714.py --control=3 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=4
python main714.py --control=3 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=4
python main714.py --control=3 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=4
python main714.py --control=4 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=4
python main714.py --control=4 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=4
python main714.py --control=4 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=4
python main714.py --control=5 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=4
python main714.py --control=5 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=4
python main714.py --control=5 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=4
python main714.py --control=6 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=4
python main714.py --control=6 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=4
python main714.py --control=6 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=4
python main714.py --control=3 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=6
python main714.py --control=3 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=6
python main714.py --control=3 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=6
python main714.py --control=4 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=6
python main714.py --control=4 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=6
python main714.py --control=4 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=6
python main714.py --control=5 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=6
python main714.py --control=5 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=6
python main714.py --control=5 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=6
python main714.py --control=6 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=6
python main714.py --control=6 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=6
python main714.py --control=6 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=6
python main714.py --control=3 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=8
python main714.py --control=3 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=8
python main714.py --control=3 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=8
python main714.py --control=4 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=8
python main714.py --control=4 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=8
python main714.py --control=4 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=8
python main714.py --control=5 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=8
python main714.py --control=5 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=8
python main714.py --control=5 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=8
python main714.py --control=6 --model=caac --train=0 --episode=10 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=8
python main714.py --control=6 --model=caac --train=0 --episode=10 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=8
python main714.py --control=6 --model=caac --train=0 --episode=10 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=8
python main714.py --control=2 --model=zhou --train=0 --episode=10 --share_scale=1 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=0
python main714.py --control=2 --model=zhou --train=0 --episode=10 --share_scale=1 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=0
python main714.py --control=2 --model=zhou --train=0 --episode=10 --share_scale=1 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=0
python main714.py --control=2 --model=zhou --train=0 --episode=10 --share_scale=1 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=2
python main714.py --control=2 --model=zhou --train=0 --episode=10 --share_scale=1 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=2
python main714.py --control=2 --model=zhou --train=0 --episode=10 --share_scale=1 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=2
python main714.py --control=2 --model=zhou --train=0 --episode=10 --share_scale=1 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=4
python main714.py --control=2 --model=zhou --train=0 --episode=10 --share_scale=1 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=4
python main714.py --control=2 --model=zhou --train=0 --episode=10 --share_scale=1 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=4
python main714.py --control=2 --model=zhou --train=0 --episode=10 --share_scale=1 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=6
python main714.py --control=2 --model=zhou --train=0 --episode=10 --share_scale=1 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=6
python main714.py --control=2 --model=zhou --train=0 --episode=10 --share_scale=1 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=6
python main714.py --control=2 --model=zhou --train=0 --episode=10 --share_scale=1 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=8
python main714.py --control=2 --model=zhou --train=0 --episode=10 --share_scale=1 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=8
python main714.py --control=2 --model=zhou --train=0 --episode=10 --share_scale=1 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=8
python main714.py --control=1 --model=fc --train=0 --episode=10 --share_scale=1 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=0
python main714.py --control=1 --model=fc --train=0 --episode=10 --share_scale=1 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=0
python main714.py --control=1 --model=fc --train=0 --episode=10 --share_scale=1 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=0
python main714.py --control=1 --model=fc --train=0 --episode=10 --share_scale=1 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=2
python main714.py --control=1 --model=fc --train=0 --episode=10 --share_scale=1 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=2
python main714.py --control=1 --model=fc --train=0 --episode=10 --share_scale=1 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=2
python main714.py --control=1 --model=fc --train=0 --episode=10 --share_scale=1 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=4
python main714.py --control=1 --model=fc --train=0 --episode=10 --share_scale=1 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=4
python main714.py --control=1 --model=fc --train=0 --episode=10 --share_scale=1 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=4
python main714.py --control=1 --model=fc --train=0 --episode=10 --share_scale=1 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=6
python main714.py --control=1 --model=fc --train=0 --episode=10 --share_scale=1 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=6
python main714.py --control=1 --model=fc --train=0 --episode=10 --share_scale=1 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=6
python main714.py --control=1 --model=fc --train=0 --episode=10 --share_scale=1 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=8
python main714.py --control=1 --model=fc --train=0 --episode=10 --share_scale=1 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=8
python main714.py --control=1 --model=fc --train=0 --episode=10 --share_scale=1 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=8
python main714.py --control=0 --model=nc --train=0 --episode=10 --share_scale=1 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=0
python main714.py --control=0 --model=nc --train=0 --episode=10 --share_scale=1 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=0
python main714.py --control=0 --model=nc --train=0 --episode=10 --share_scale=1 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=0
python main714.py --control=0 --model=nc --train=0 --episode=10 --share_scale=1 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=2
python main714.py --control=0 --model=nc --train=0 --episode=10 --share_scale=1 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=2
python main714.py --control=0 --model=nc --train=0 --episode=10 --share_scale=1 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=2
python main714.py --control=0 --model=nc --train=0 --episode=10 --share_scale=1 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=4
python main714.py --control=0 --model=nc --train=0 --episode=10 --share_scale=1 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=4
python main714.py --control=0 --model=nc --train=0 --episode=10 --share_scale=1 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=4
python main714.py --control=0 --model=nc --train=0 --episode=10 --share_scale=1 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=6
python main714.py --control=0 --model=nc --train=0 --episode=10 --share_scale=1 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=6
python main714.py --control=0 --model=nc --train=0 --episode=10 --share_scale=1 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=6
python main714.py --control=0 --model=nc --train=0 --episode=10 --share_scale=1 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=8
python main714.py --control=0 --model=nc --train=0 --episode=10 --share_scale=1 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=8
python main714.py --control=0 --model=nc --train=0 --episode=10 --share_scale=1 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=8