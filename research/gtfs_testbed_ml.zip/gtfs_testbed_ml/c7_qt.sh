python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=0
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=2
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=4
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=6
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=8