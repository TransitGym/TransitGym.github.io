set -e
python main714.py --control=7 --model=caac --train=1 --episode=800 --share_scale=0 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main714.py --control=7 --model=caac --train=1 --episode=800 --share_scale=0 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main714.py --control=7 --model=caac --train=1 --episode=800 --share_scale=0 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=0
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=0
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=0
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=2
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=2
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=2
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=4
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=4
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=4
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=6
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=6
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=6
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=0 --vis=0 --restore=1 --w=6 --all=1 --shares=8
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=1 --vis=0 --restore=1 --w=6 --all=1 --shares=8
python main714.py --control=7 --model=caac --train=0 --episode=6 --share_scale=0 --seed=2 --vis=0 --restore=1 --w=6 --all=1 --shares=8