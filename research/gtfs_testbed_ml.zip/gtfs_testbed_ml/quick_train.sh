python main.py --control=5 --model=caac --train=1 --episode=800 --share_scale=0 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main.py --control=6 --model=caac --train=1 --episode=800 --share_scale=0 --seed=2 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main.py --control=5 --model=caac --train=1 --episode=800 --share_scale=0 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main.py --control=6 --model=caac --train=1 --episode=800 --share_scale=0 --seed=0 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0 
python main.py --control=5 --model=caac --train=1 --episode=800 --share_scale=0 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0
python main.py --control=6 --model=caac --train=1 --episode=800 --share_scale=0 --seed=1 --vis=0 --restore=0 --w=6 --all=1 --shares=-1 --stop_embedding=0