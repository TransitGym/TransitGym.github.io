sh quick_train.sh
sh quick_run.sh